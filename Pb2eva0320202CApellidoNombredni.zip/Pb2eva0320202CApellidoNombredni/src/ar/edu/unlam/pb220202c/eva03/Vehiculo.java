package ar.edu.unlam.pb220202c.eva03;

public class Vehiculo {

	//Se debe crear contructeres getters y Setters y loos que crean convenientes
	public String Patente;
	public Integer VelocidadActual;
	public Integer limiteVelocidad;

	
	public void incrmentarVelocidad(Integer Velocidad) {
		
	}
}
