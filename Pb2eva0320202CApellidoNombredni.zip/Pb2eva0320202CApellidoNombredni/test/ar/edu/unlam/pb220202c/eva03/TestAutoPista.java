package ar.edu.unlam.pb220202c.eva03;

public class TestAutoPista {
	
	
	public void queSePuedaRegistrarTelepase () {
		
	}

	public void queAlSalirDelAutopistaNoestaEncirculacionLanceUnaExcepcion() {
		
	}
	
	public void queVerifiqueQueSeObtengaUnaListaDeAutosInsfractoresOrdenadaPorPatente(){
		
	}

	public void generetestAEleccion1() {
		
	}
	
	public void generetestAEleccion2() {
		
	}
	
}
